
function validate() {
    var fn = frm.fname.value;
    localStorage.setItem("firstname", fn);
    for (let i = 0; i < fn.length; i++) {
        let ch = fn.charCodeAt(i);
        if ((ch < 65 || ch > 90) && (ch < 97 || ch > 122)) {
            alert("Invalid firstname");
            return false;
        }
    }

    var ln = frm.lname.value;
    localStorage.setItem("lastname", ln);
    for (let i = 0; i < ln.length; i++) {
        let ch = ln.charCodeAt(i);
        if ((ch < 65 || ch > 90) && (ch < 97 || ch > 122)) {
            alert("Invalid lastname");
            return false;
        }
    }

    var phn = frm.phone.value;
    localStorage.setItem("phone", phn);
    if (!/^\d{10}$/.test(phn)) {
        alert("Phone number must be exactly 10 digits and numeric.");
        return false;
    }

    var pwd1 = frm.pwd.value;
    localStorage.setItem("password", pwd1);
    var pwdl = pwd1.length;
    if (pwdl % 2 === 1) {
        alert("Password should contain even number of characters");
        return false;
    }
    if (pwdl > 8) {
        alert("Password should not exceed 8 characters");
        return false;
    }

    var mail = frm.mailid.value;
    localStorage.setItem("email", mail);
    var reg = /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/;
    if (!reg.test(mail)) {
        alert("Invalid email");
        return false;
    }

    alert("Registration Successful!! Please login now.");
    window.location.href = "login.html"; 
    return false; 
}
